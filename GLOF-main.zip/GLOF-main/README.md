# GLOF
Developed a system to predict Glacial Lake Outburst Floods (GLOFs) using real-time IoT sensor data and historical trends. Achieved accurate early warning notifications using time-series data analysis.
